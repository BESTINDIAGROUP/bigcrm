// Best India Group CRM - automatic backups.  Version v16
// Every night (about 2 AM) a full copy of the data Sheet and a .json restore file are saved
// in the Google Drive folder "Best India Group CRM - Backups". The last 30 days are kept.
// Run setupAutoBackup() once from the editor (press Run, then Allow).
//
// Email: NOTIFY = "daily", "weekly" (Mondays) or "off". If a backup ever fails you always get an email.
const BACKUP_FOLDER = "Best India Group CRM - Backups";
const KEEP_DAYS = 30;
const NOTIFY = "weekly";
const ALERT_EMAIL = ""; // leave empty to use the owner's Google email

function backupFolder_() {
  const it = DriveApp.getFoldersByName(BACKUP_FOLDER);
  return it.hasNext() ? it.next() : DriveApp.createFolder(BACKUP_FOLDER);
}
function mailTo_() { return ALERT_EMAIL || Session.getEffectiveUser().getEmail(); }
function stamp_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy-MM-dd HH-mm"); }

// Makes a backup now. Run it any time from the editor.
function backupNow() {
  try {
    const ss = ss_(), folder = backupFolder_(), st = stamp_();
    const copy = DriveApp.getFileById(ss.getId()).makeCopy("CRM backup " + st, folder);
    const d = readAll_();
    const json = JSON.stringify({ app: "Best India Group CRM", made: new Date().toISOString(), cfg: d.cfg, leads: d.leads, tasks: d.tasks });
    const jf = folder.createFile("CRM backup " + st + ".json", json, "application/json");
    props_().setProperty("LAST_BACKUP", JSON.stringify({ t: new Date().toISOString(), json: jf.getId(), sheet: copy.getId(), leads: d.leads.length, tasks: d.tasks.length }));
    // keep only the last KEEP_DAYS days
    const cut = Date.now() - KEEP_DAYS * 864e5, it = folder.getFiles();
    while (it.hasNext()) { const f = it.next(); if (f.getName().indexOf("CRM backup ") === 0 && f.getDateCreated().getTime() < cut) f.setTrashed(true); }
    const mon = new Date().getDay() === 1;
    if (NOTIFY === "daily" || (NOTIFY === "weekly" && mon)) {
      MailApp.sendEmail({ to: mailTo_(), subject: "✅ CRM backup done " + st, body: "Your Best India Group CRM backup was saved in Google Drive (folder: " + BACKUP_FOLDER + ").\n" + d.leads.length + " leads/projects, " + d.tasks.length + " tasks.\nThe .json restore file is attached.", attachments: [jf.getBlob()] });
    }
    Logger.log("Backup saved: " + copy.getUrl());
    return copy.getUrl();
  } catch (e) {
    try { MailApp.sendEmail(mailTo_(), "⚠ CRM backup FAILED", "The automatic backup did not work: " + e.message + "\nOpen the Apps Script editor and run backupNow() to try again."); } catch (x) {}
    throw e;
  }
}

// Turns on the nightly backup. Run once from the editor.
function setupAutoBackup() {
  ScriptApp.getProjectTriggers().filter(t => /^backupNow$/.test(t.getHandlerFunction())).forEach(t => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger("backupNow").timeBased().everyDays(1).atHour(2).create();
  Logger.log("Nightly backup is on. Backups go to the Drive folder: " + BACKUP_FOLDER);
  backupNow();
}
function stopAutoBackup() {
  ScriptApp.getProjectTriggers().filter(t => t.getHandlerFunction() === "backupNow").forEach(t => ScriptApp.deleteTrigger(t));
  Logger.log("Nightly backup is off.");
}
function listBackups() {
  const it = backupFolder_().getFiles(), files = [];
  while (it.hasNext()) files.push(it.next());
  files.sort((a, b) => b.getDateCreated() - a.getDateCreated());
  files.forEach(f => Logger.log(f.getName() + "  " + f.getUrl()));
  if (!files.length) Logger.log("No backups yet. Run backupNow().");
}
function lastBackupTime() { Logger.log(props_().getProperty("LAST_BACKUP") || "No backup yet."); }

/* ---- for the admin inside the app ---- */
function crmBackupInfo(t) {
  const me = auth_(t); if (!me.admin) throw new Error("Admins only");
  try { return JSON.parse(props_().getProperty("LAST_BACKUP") || "null"); } catch (e) { return null; }
}
function crmBackupGet(t) {
  const me = auth_(t); if (!me.admin) throw new Error("Admins only");
  const info = JSON.parse(props_().getProperty("LAST_BACKUP") || "null");
  if (!info) throw new Error("No automatic backup yet. Run setupAutoBackup() in the editor.");
  return { name: "CRM backup " + info.t.slice(0, 10) + ".json", text: DriveApp.getFileById(info.json).getBlob().getDataAsString() };
}